/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   creat_filehash.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soohlee <soohlee@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/15 16:52:32 by soohlee           #+#    #+#             */
/*   Updated: 2023/04/15 18:09:40 by soohlee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int creat_filehash(char ***file)
{
    *file = (char **)malloc(sizeof(char *) * 7);
    if (!*file)
        return (0);
    *file['0'] = ft_strdup("./back_ground.xpm");
    *file['1'] = ft_strdup("./wall.xpm");
    *file['C'] = ft_strdup("./collect.xpm");
    *file['E'] = ft_strdup("./exit.xpm");
    *file['P'] = ft_strdup("./yoda.xpm");
    *file['S'] = ft_strdup("./start.xpm");
    return (0);
}